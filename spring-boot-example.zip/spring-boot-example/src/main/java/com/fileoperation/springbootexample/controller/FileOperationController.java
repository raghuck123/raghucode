package com.fileoperation.springbootexample.controller;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.validation.Valid;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fileoperation.springbootexample.constant.FileOperationConstant;
import com.fileoperation.springbootexample.exception.ResourceNotFoundException;
import com.fileoperation.springbootexample.model.FileData;
import com.fileoperation.springbootexample.repository.FileOperationRepository;
import com.fileoperation.springbootexample.service.FileOperationService;
import com.fileoperation.springbootexample.service.FileOperationServiceImpl;


@RestController
//@RequestMapping("/api/v1")
public class FileOperationController {

	@Autowired  
	FileOperationService fileOperationService;  
	String status = "InProgress";
	
	/* The code below will write data to 
	 * file based on task id in descending order */
    //http://localhost:8083//writeToTextFile/88
	
    @PostMapping("/writeToTextFile/{id}")
	public String writeToTextFile(@PathVariable(value = "id") int taskId) {
		try {

			status = taskId + " " + "Inprogress";
			File file = fileOperationService.writeFile(taskId);
			return FileOperationConstant.TASK_COMPLETED + FileOperationConstant.FILE_CREATED_UNDER + file.getCanonicalPath();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FileOperationConstant.TASK_COMPLETED;
	}
    /* The code below will read data to 
	 * file based on task id in descending order */
  @GetMapping("/readTextFile/{id}")
    public List<String>readsmallfile(@PathVariable(value = "id") Long taskId) throws ResourceNotFoundException {
    	String result = "";
    	 try {
    		List<String> lines = fileOperationService.readFile(taskId);
    		
    	 return lines;
    	 } catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 return null;
    }


  /* The code below will check the status for the task idr */
    @GetMapping("/getStatus/{id}")
    public String getStatus(@PathVariable(value = "id") Long taskId) throws ResourceNotFoundException {
    	String result = "";
    	try {
    		if(status.contains(taskId.toString())) {
    			
    			return FileOperationConstant.FILE_OPERATION_STATUS_IN_PROGRESS;
    		} else {
    			
    			return FileOperationConstant.FILE_OPERATION_STATUS_COMPLETED;
    		}
    		
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return null;
    }
 
 


    	
    
}
