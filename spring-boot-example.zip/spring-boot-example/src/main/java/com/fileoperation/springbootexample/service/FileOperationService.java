package com.fileoperation.springbootexample.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface FileOperationService {
	public File writeFile(int taskId) throws IOException ;
	public List<String> readFile(Long taskId) throws IOException;
	
	
}
