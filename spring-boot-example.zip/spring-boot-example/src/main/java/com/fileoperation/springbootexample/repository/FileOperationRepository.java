package com.fileoperation.springbootexample.repository;

import org.springframework.stereotype.Repository;

import com.fileoperation.springbootexample.model.FileData;



@Repository
public interface FileOperationRepository {

}
