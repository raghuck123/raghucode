package com.fileoperation.springbootexample.service;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fileoperation.springbootexample.model.FileData;  
@Service  
public class FileOperationServiceImpl implements FileOperationService {
	
	public File writeFile(int taskId) throws IOException {
		File directory = new File("E:/temp");
		 if (!directory.exists()) {
			 directory.mkdir();
		 }
		
		String filePath = "D:/temp/temp" + taskId + ".txt";
		File file = new File(filePath);
		file.createNewFile();
	
		FileWriter fw = new FileWriter(file.getCanonicalPath());
		for (int i = taskId; i >= 0; i--) {
		    if(i%2 ==0) {
			fw.write(String.valueOf(" " + i));
		    }

		}

		fw.close();
		return file;
	}
	
	public List<String> readFile(Long taskId) throws IOException {
		String fileName = "";
		fileName = "D:\\temp\\temp"+taskId+".txt";
		//fileName = "E:\\temp\\temp1000.txt";
		FileData emp = new FileData();
		    // String fileName = "E:\\temp"+100000+".txt";
		List<String> lines = Files.readAllLines(Paths.get(fileName));
		return lines;
	} 

}
