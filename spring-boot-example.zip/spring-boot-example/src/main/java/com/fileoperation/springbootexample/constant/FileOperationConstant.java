package com.fileoperation.springbootexample.constant;

public class FileOperationConstant {

	public static final String TASK_COMPLETED = "Task Completed";
	
	public static final String FILE_CREATED_UNDER = "File Created Under";
	
	public static final String FILE_OPERATION_STATUS_IN_PROGRESS = "In Progress";
	
	public static final String FILE_OPERATION_STATUS_COMPLETED = "Completed";
	
}
